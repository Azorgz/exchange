function ClassMap(CM,cmap,legend)
% Show the classification map with the given cmap and legend
str = [' Classification map for ',inputname(1)];
imshow(CM,cmap,'Border','tight')
title(str)
imlegend(cmap, legend)
set(gcf,'Color','white','Name',str,'Position',[5 500 1905 450]);
