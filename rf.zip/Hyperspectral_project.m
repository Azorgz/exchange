%% Setup the environnement and load the datacube
clc;
clear all;
close all;
addpath(genpath('RF classifier'));
addpath(genpath('ShallowFE'));
addpath(genpath('DeepFE'));
addpath(genpath('2013_DFTC'));

load('Houston');
HSI = double(Houston);
load TRLabel
load TSLabel
Tr = TRLabel;
Te = TSLabel;
clear TRLabel TSLabel Houston

%% Parameter setting
dim = 15; % for Houston2013
Trees = 200; % for RF training


%% III- PCA and OTVCA analysis %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[nx,ny,nz]=size(HSI);
data=double(reshape(HSI,nx*ny,nz));
[~, SCORE] = pca(data,'Algorithm','svd','NumComponents',dim);
FE_Mpca=reshape(SCORE,nx,ny,dim);
data = double(HSI);
FE_OTVCA=OTVCA_V3(data,dim);
clear SCORE data
%% Result Comparison
clc
OTVCA = Normegalize(OTVCA);
OTVCA = 65535-OTVCA;
PCA = Normegalize(PCA);
bands = [1,3,6,10];
% Compare(PCA,OTVCA,bands,0)
%%
i = 1;
imshow(PCA(:,:,bands(i)),'Border','tight')
set(gcf,'Color','white','Position',[10 500 1905 349]);
%% IV- LDA and JPLAY Comparison
clc
[m, n, z] = size(HSI);
HSI2d = double(hyperConvert2d(HSI));

TrainI2d = hyperConvert2d(Tr);
TestI2d = hyperConvert2d(Te);

l_Tr = find(TrainI2d > 0);
Samples_Tr = HSI2d(:, l_Tr);
Labels_Tr = TrainI2d(:, l_Tr);

l_Te = find(TestI2d > 0);
Samples_Te = HSI2d(:, l_Te);
Labels_Te = TestI2d(:, l_Te);

%% LDA
[~, mapping] = lda(Samples_Tr', Labels_Tr', dim-1);
M = mapping.M;
LDA = reshape(HSI2d' * M,m, n, dim-1);
%% JPLAY
HSI2d = double(DataNormlization(HSI2d));
num = 10;
sigma = 0.1;
alfa = 1;
beta = 0.1;
gamma = 0.1;
rho = 2;
maxiter = 1000;
eta = 1;
epsilon = 1e-3;

k = 20;
% data clustering to reduce the computional complexity
% In Cluster function change : 
% if not(isnan(N))
%      NN=[NN,mean(N,2)];
% end
% In the last loop
[NewSamples_Tr, NewLabels_Tr] = ClusterCenter(Samples_Tr, Labels_Tr, k);
Y = GeneLableY(NewLabels_Tr, max(NewLabels_Tr)); % l*N_train: l is the number of class
% Construct adjacency matrix and Laplacian matrix
[G, L] = creatLap(NewSamples_Tr, num, sigma); % Return adjacency matrix G and Laplacian matrix L
% Evenly give the middle subspace dimensions
layer = 15; % Layers: you can tune it accordingly and here we just give an example.
d = generatePath(z, layer, dim); % Generate the dimension sequence for intermediate subspaces
% Run JPLAY to learn projections on train samples
% IN DR_LPP just before the call to LPP add : options.Regu=1;options.ReguAlpha=0.1;
[theta, P, res] = JPLAY(NewSamples_Tr, Y, G, L, num, d, sigma, alfa, beta, gamma, rho, maxiter, eta, epsilon);
Jplay=HSI2d;
for i = 1 : dim
    Jplay = theta{1, i} * Jplay;
end
Jplay = reshape(Jplay',m, n, 15);
clear HSI2d num sigma alfa beta gamma rho maxiter eta epsilon k Y G L d

%% Results Comparison
JPLAY = Normegalize(JPLAY);
LDA = Normegalize(LDA);
bands = [1,3,6,10];
Compare(LDA,JPLAY,bands,0)
%%
i =4;
x = OTVCA(cut,cut1,bands(i));
imshow(x,'Border','tight')
set(gcf,'Color','white','Position',[10 500 length(x(1,:,1)) length(x(:,1,1))]);
%% V- Random Forest Classifier
dim = 15;
Trees = 200;
[m,n] = size(HSI);

%% RF on Spectral Features

[acc_Mean,~,CM_HSI,class_acc_HSI]=RF_ntimes_overal(HSI,Tr,Te,Trees);
aa_HSI=mean(acc_Mean(1:dim,1));
oa_HSI=acc_Mean(dim+2,1);
K_HSI=acc_Mean(dim+3,1);
%% RF - LDA
[oa_LDA, pa, K_LDA, CM_LDA, class_acc_LDA] = SFE_LDA(HSI, Tr, Te, dim, Trees);
aa_LDA = mean(pa);

%% OTVCA
[acc_Mean,~,CM_OTVCA,class_acc_OTVCA]=RF_ntimes_overal(OTVCA,Tr,Te,Trees);
aa_OTVCA=mean(acc_Mean(1:dim,1));
oa_OTVCA=acc_Mean(dim+2,1);
K_OTVCA=acc_Mean(dim+3,1);


%% PCA
% [nx,ny,nz]=size(HSI);
% data=reshape(HSI,nx*ny,nz);
% [data] = pca(data');
% FE_Mpca=reshape(data(:,1:dim),nx,ny,dim);
[acc_Mean,~,CM_PCA,class_acc_PCA]=RF_ntimes_overal(PCA,Tr,Te,Trees);
aa_PCA=mean(acc_Mean(1:dim,1));
oa_PCA=acc_Mean(dim+2,1);
K_PCA=acc_Mean(dim+3,1);

%% JPLAY
num = 10;
sigma = 0.1;
alfa = 1;
beta = 0.1;
gamma = 0.1;
rho = 2;
maxiter = 1000;
eta = 1;
epsilon = 1e-4;
[oa_JPLAY, pa, K_JPLAY, CM_JPLAY, class_acc_JPLAY] = SFE_JPLAY(HSI, Tr, Te, dim, num, sigma, alfa, beta, gamma, rho, maxiter, eta, epsilon, Trees);
aa_JPLAY = mean(pa);

%% Compare the classification map
ClassMap(CM_OTVCA,cmap,legend)